var searchData=
[
  ['run',['run',['../class_practica4_1_1_jugador.html#a95fb1e508af2d77aee30222cb64199c2',1,'Practica4::Jugador']]]
];

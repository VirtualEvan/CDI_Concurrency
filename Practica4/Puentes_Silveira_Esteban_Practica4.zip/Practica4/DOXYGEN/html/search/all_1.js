var searchData=
[
  ['getestado',['getEstado',['../class_practica4_1_1_pelota.html#ac35ca764f2c6e26db922a6f5c726fc18',1,'Practica4::Pelota']]],
  ['getjugadas',['getJugadas',['../class_practica4_1_1_pelota.html#ad72f2a2d2a0b26f3b19ace9ed6cf65d3',1,'Practica4::Pelota']]],
  ['getjugadores',['getJugadores',['../class_practica4_1_1_pelota.html#a1149eb47d7a21c21710d00e5c223e527',1,'Practica4::Pelota']]],
  ['getmaxjugadas',['getMaxJugadas',['../class_practica4_1_1_pelota.html#ad9423a6e3d425befd4c6809f0a7739a3',1,'Practica4::Pelota']]],
  ['getmodalidad',['getModalidad',['../class_practica4_1_1_pelota.html#aee2a61575064881875d6bcfc836f4fa9',1,'Practica4::Pelota']]],
  ['gettexto',['getTexto',['../class_practica4_1_1_pelota.html#ac45780f814a1c62684087f68a18b6f1e',1,'Practica4::Pelota']]],
  ['getturno',['getTurno',['../class_practica4_1_1_pelota.html#a188f4792d7cba45b3ccd838712f2da45',1,'Practica4::Pelota']]]
];

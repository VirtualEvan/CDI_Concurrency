var searchData=
[
  ['incrementarjugada',['incrementarJugada',['../class_practica4_1_1_pelota.html#add2d52594c65fce854d719668d923721',1,'Practica4::Pelota']]]
];

var searchData=
[
  ['jugador',['Jugador',['../class_practica4_1_1_jugador.html#aee0431507107aa41280193b75e396437',1,'Practica4::Jugador']]]
];

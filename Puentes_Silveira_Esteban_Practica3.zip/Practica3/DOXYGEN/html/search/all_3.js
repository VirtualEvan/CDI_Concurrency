var searchData=
[
  ['enterandwait',['EnterAndWait',['../class_practica3_1_1_a.html#aba405116e569ea00ef5800906f331cd8',1,'Practica3::A']]]
];

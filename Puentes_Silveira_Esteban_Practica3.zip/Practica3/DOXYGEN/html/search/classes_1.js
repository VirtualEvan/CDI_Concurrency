var searchData=
[
  ['b',['B',['../class_practica3_1_1_b.html',1,'Practica3']]]
];

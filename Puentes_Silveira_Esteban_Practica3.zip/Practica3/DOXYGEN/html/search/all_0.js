var searchData=
[
  ['a',['A',['../class_practica3_1_1_a.html',1,'Practica3']]]
];

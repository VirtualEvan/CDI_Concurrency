var searchData=
[
  ['jugador',['Jugador',['../class_practica4_1_1_jugador.html',1,'Practica4']]]
];

var searchData=
[
  ['setestado',['setEstado',['../class_practica4_1_1_pelota.html#a7a63bb6a91aa761d199bf4f52121929c',1,'Practica4::Pelota']]],
  ['settexto',['setTexto',['../class_practica4_1_1_pelota.html#aca64e664ed97d572b2965dad0f3a6b7c',1,'Practica4::Pelota']]],
  ['setturno',['setTurno',['../class_practica4_1_1_pelota.html#ab11c5110d330f07f4ae8c6db9a4ffc10',1,'Practica4::Pelota']]]
];

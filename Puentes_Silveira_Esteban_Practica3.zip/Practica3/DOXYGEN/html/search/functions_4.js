var searchData=
[
  ['run',['run',['../class_practica3_1_1_b.html#afd28d42d2ac7d35ac97c3969f82bf9f5',1,'Practica3.B.run()'],['../class_practica3_1_1_hilo.html#ae8e47d60f2c0045078cf1dbcab6c5a1f',1,'Practica3.Hilo.run()']]]
];
